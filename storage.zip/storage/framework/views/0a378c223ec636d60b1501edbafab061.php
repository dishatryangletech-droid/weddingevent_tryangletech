<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php echo $__env->yieldContent('title', 'Admin Dashboard'); ?> | Elegant Occasions Admin</title>
  
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/favicon.png')); ?>" />
  
  <!-- Backend Admin Styles -->
  <link rel="stylesheet" href="<?php echo e(asset('backend/css/admin.css')); ?>?v=<?php echo e(time()); ?>" />
  
  <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
  <div class="admin-wrapper">
    <!-- Sidebar -->
    <?php echo $__env->make('backend.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <!-- Main Content -->
    <div class="admin-main">
      <!-- Top Header -->
      <header class="admin-header">
        <div class="header-left">
          <button type="button" class="mobile-menu-btn" id="mobileSidebarToggle" aria-label="Toggle Sidebar">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="3" y1="12" x2="21" y2="12"></line>
              <line x1="3" y1="6" x2="21" y2="6"></line>
              <line x1="3" y1="18" x2="21" y2="18"></line>
            </svg>
          </button>
          <div class="header-title"><?php echo $__env->yieldContent('page_title', 'Dashboard'); ?></div>
        </div>

        <div class="header-right">
          <a href="<?php echo e(route('home')); ?>" target="_blank" class="header-site-link" title="Open public website">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
              <polyline points="15 3 21 3 21 9"></polyline>
              <line x1="10" y1="14" x2="21" y2="3"></line>
            </svg>
            <span>View Website</span>
          </a>

          <div class="user-profile-menu">
            <div class="avatar"><?php echo e(strtoupper(substr(Auth::user()->name ?? 'A', 0, 1))); ?></div>
            <div style="font-size: 0.88rem; font-weight: 600;"><?php echo e(Auth::user()->name ?? 'Administrator'); ?></div>
          </div>
        </div>
      </header>

      <!-- Body Content -->
      <main class="admin-body">
        <!-- Flash Alerts -->
        <?php if(session('success')): ?>
          <div class="alert alert-success">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
              <span><?php echo e(session('success')); ?></span>
            </div>
            <button type="button" onclick="this.parentElement.remove()" style="background:none;border:none;color:inherit;cursor:pointer;">&times;</button>
          </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
          <div class="alert alert-danger">
            <div style="display: flex; align-items: center; gap: 0.5rem;">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="15" y1="9" x2="9" y2="15"></line>
                <line x1="9" y1="9" x2="15" y2="15"></line>
              </svg>
              <span><?php echo e(session('error')); ?></span>
            </div>
            <button type="button" onclick="this.parentElement.remove()" style="background:none;border:none;color:inherit;cursor:pointer;">&times;</button>
          </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
          <div class="alert alert-danger">
            <div>
              <strong>Please check the errors below:</strong>
              <ul style="margin-top: 0.35rem; padding-left: 1.25rem;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>
            <button type="button" onclick="this.parentElement.remove()" style="background:none;border:none;color:inherit;cursor:pointer;">&times;</button>
          </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
      </main>
    </div>
  </div>

  <!-- Backend Admin JS -->
  <script src="<?php echo e(asset('backend/js/admin.js')); ?>?v=<?php echo e(time()); ?>"></script>
  <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH E:\Disha Suthar\GitProject\weddingevent_tryangletech\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>