<?php $__env->startSection('title', 'Edit Testimonial'); ?>
<?php $__env->startSection('page_title', 'Testimonials > Edit'); ?>

<?php $__env->startSection('content'); ?>
  <div class="admin-card">
    <div class="card-header">
      <div>
        <div class="card-title">Edit Testimonial</div>
        <div class="card-subtitle">Update review from <?php echo e($testimonial->name); ?>.</div>
      </div>
      <a href="<?php echo e(route('admin.testimonials.index')); ?>" class="btn btn-secondary">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="19" y1="12" x2="5" y2="12"></line>
          <polyline points="12 19 5 12 12 5"></polyline>
        </svg>
        <span>Back to List</span>
      </a>
    </div>
    
    <div class="card-body" style="padding: 1.5rem;">
      <form action="<?php echo e(route('admin.testimonials.update', $testimonial->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
          <div class="form-group">
            <label class="form-label">Client Name *</label>
            <input type="text" name="name" class="form-control" required value="<?php echo e(old('name', $testimonial->name)); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red; font-size: 0.8rem;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-label">Headline (Short Title)</label>
            <input type="text" name="headline" class="form-control" value="<?php echo e(old('headline', $testimonial->headline)); ?>">
            <?php $__errorArgs = ['headline'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red; font-size: 0.8rem;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group" style="margin-bottom: 1.5rem;">
          <label class="form-label">Review Text *</label>
          <textarea name="review" class="form-control" rows="4" required><?php echo e(old('review', $testimonial->review)); ?></textarea>
          <?php $__errorArgs = ['review'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red; font-size: 0.8rem;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-bottom: 1.5rem;">
          <div class="form-group">
            <label class="form-label">Client Image / Avatar</label>
            <?php if($testimonial->image): ?>
              <div style="margin-bottom: 0.5rem;">
                <img src="<?php echo e(asset('storage/'.$testimonial->image)); ?>" alt="Current Image" style="width: 60px; height: 60px; object-fit: cover; border-radius: 50%;">
              </div>
            <?php endif; ?>
            <input type="file" name="image" class="form-control" accept="image/*">
            <small style="color: var(--text-muted);">Leave blank to keep current image</small>
            <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span style="color: red; font-size: 0.8rem;"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="form-group">
            <label class="form-label">Display Status</label>
            <select name="status" class="form-control">
              <option value="active" <?php echo e(old('status', $testimonial->status) == 'active' ? 'selected' : ''); ?>>Active (Show)</option>
              <option value="inactive" <?php echo e(old('status', $testimonial->status) == 'inactive' ? 'selected' : ''); ?>>Inactive (Hide)</option>
            </select>
          </div>
        </div>

        <div class="form-group" style="max-width: 200px; margin-bottom: 2rem;">
          <label class="form-label">Sort Order</label>
          <input type="number" name="sort_order" class="form-control" value="<?php echo e(old('sort_order', $testimonial->sort_order)); ?>" required>
          <small style="color: var(--text-muted);">Lower numbers appear first</small>
        </div>

        <button type="submit" class="btn btn-primary">Update Testimonial</button>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Disha Suthar\GitProject\weddingevent_tryangletech\resources\views/backend/testimonials/edit.blade.php ENDPATH**/ ?>