<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Admin Login | Elegant Occasions</title>
  
  <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('images/elegant_occasions_logo.png')); ?>" />
  <link rel="stylesheet" href="<?php echo e(asset('backend/css/admin.css')); ?>?v=<?php echo e(time()); ?>" />
</head>
<body>
  <div class="auth-page">
    <div class="auth-card">
      <div class="auth-brand">
        <div style="display: flex; justify-content: center; margin-bottom: 0.85rem;">
          <img src="<?php echo e(asset('images/elegant_occasions_logo.png')); ?>" alt="Elegant Occasions" style="height: 75px; width: auto; max-width: 220px; object-fit: contain;" />
        </div>
        <p>Sign in to access your administrative dashboard</p>
      </div>

      <?php if(session('success')): ?>
        <div class="alert alert-success" style="font-size: 0.85rem;">
          <?php echo e(session('success')); ?>

        </div>
      <?php endif; ?>

      <?php if($errors->any()): ?>
        <div class="alert alert-danger" style="font-size: 0.85rem;">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div><?php echo e($err); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(route('admin.login.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="form-group">
          <label class="form-label" for="email">Email Address</label>
          <input 
            type="email" 
            id="email" 
            name="email" 
            value="<?php echo e(old('email', 'admin@gmail.com')); ?>" 
            class="form-control" 
            placeholder="name@company.com" 
            required 
            autofocus 
          />
        </div>

        <div class="form-group">
          <label class="form-label" for="password">Password</label>
          <input 
            type="password" 
            id="password" 
            name="password" 
            class="form-control" 
            placeholder="••••••••" 
            required 
          />
        </div>

        <div class="form-group" style="display: flex; align-items: center; justify-content: space-between; margin-top: 0.5rem; margin-bottom: 1.5rem;">
          <label style="display: flex; align-items: center; gap: 0.5rem; font-size: 0.85rem; color: var(--text-muted); cursor: pointer;">
            <input type="checkbox" name="remember" value="1" style="accent-color: var(--primary);" />
            <span>Remember me</span>
          </label>
        </div>

        <button type="submit" class="btn btn-primary" style="width: 100%; padding: 0.85rem;">
          <span>Sign In to Dashboard</span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polyline points="9 18 15 12 9 6"></polyline>
          </svg>
        </button>
      </form>

      <div style="text-align: center; margin-top: 1.75rem; font-size: 0.82rem; color: var(--text-dim);">
        &copy; <?php echo e(date('Y')); ?> Elegant Occasions. All rights reserved.
      </div>
    </div>
  </div>
</body>
</html>
<?php /**PATH E:\Disha Suthar\GitProject\weddingevent_tryangletech\resources\views/backend/auth/login.blade.php ENDPATH**/ ?>